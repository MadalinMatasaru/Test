package com.testing;

import java.awt.Image;
import java.awt.Label;
import java.awt.TextField;

import javax.imageio.ImageIO;
import javax.swing.text.LabelView;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.rules.Timeout;

import unittesting.UnitTestClassBase;

import com.google.common.collect.Table.Cell;
import com.hp.lft.report.Reporter;
import com.hp.lft.sdk.*;
import com.hp.lft.sdk.java.*;
import com.hp.lft.sdk.sap.gui.LabelDescription;
import com.hp.lft.sdk.stdwin.EditorDescription;
import com.hp.lft.sdk.web.ButtonDescription;
import com.hp.lft.sdk.web.XPathDescription;
import com.hp.lft.sdk.winforms.WindowDescription;
import com.hp.lft.verifications.Verify;
import com.hp.lft.sdk.insight.*;

import java.awt.image.*;
import java.io.File;
import java.io.IOException;

import static org.junit.Assert.*;

public class FTest extends UnitTestClassBase {

	public FTest() {
		//Change this constructor to private if you supply your own public constructor
	}

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		instance = new FTest();
		globalSetup(FTest.class);
		Runtime.getRuntime().exec("C:\\Program Files (x86)\\HPE SA\\launcher\\hpe_sa_launcher.exe");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		globalTearDown();
	}
	
	@Before
	public void setUp() throws Exception {
		//Start the application
	     Window saWin =  Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
			.title("HPE Server Automation Client Login").build());
	     
	     //Login into the application and wait 20 seconds for the Server Automation app to load
	     saWin.describe(List.class, new ListDescription.Builder().attachedText("Core Server:").build()).select("192.168.178.30");
	     saWin.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Continue").build()).click();
	     saWin.describe(Editor.class, new EditorDescription.Builder()
			.attachedText("User Name:").build()).setText("ta");
	     saWin.describe(Editor.class, new EditorDescription.Builder()
			.attachedText("Password:").build()).setText("opsware");
	     saWin.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Log In").build()).click();
         try {Thread.sleep(20000);} catch (InterruptedException e) {e.printStackTrace();}
	}
	@Test
	public void test() throws GeneralLeanFtException {
		 //Select Library and then Import Software form the Actions menu      
		
		Window afterLoginWindow =  Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
		.title("HPE Server Automation - 192.168.178.30").build());
		
		Window testPolicyWindow = Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
		.title("Software Policy: test policy*").build()); 
		
		 afterLoginWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Library").build()).click();
		 afterLoginWindow.describe(TreeView.class, new TreeViewDescription.Builder()
			.attachedText("Library").build()).select("By Type;Packages;Red Hat;Red Hat Enterprise Linux Server 5");
         try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}  
         afterLoginWindow.describe(Menu.class, new MenuDescription.Builder()
			.label("Actions").build()).click();
         try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
         afterLoginWindow.describe(Menu.class, new MenuDescription.Builder()
			.label("Actions").build()).selectSubMenu("Import Software...");
         try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
         
         // Import a dummy .zip file - the Browse buttons are identical so that we need to use Location property to distinguish them
         // also close all the modal windows that are being opened
        
         afterLoginWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
  			.attachedText("Browse...").index(0).build()).click();
         try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
         afterLoginWindow.describe(Dialog.class, new DialogDescription.Builder()
			.title("Software Imports").build()).describe(Dialog.class, new DialogDescription.Builder()
			.title("Open").build()).describe(Editor.class, new EditorDescription.Builder()
			.attachedText("File Name:").build()).setText("test.zip");
         afterLoginWindow.describe(Dialog.class, new DialogDescription.Builder()
			.title("Software Imports").build()).describe(Dialog.class, new DialogDescription.Builder()
			.title("Open").build()).describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Open").build()).click();
         afterLoginWindow.describe(Dialog.class, new DialogDescription.Builder()
			.title("Software Imports").build()).describe(Editor.class, new EditorDescription.Builder()
			.attachedText("Folder:").build()).setText("/");
         afterLoginWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Import").build()).click();
         afterLoginWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Replace").build()).click();
         try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
         Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
			.title("Software Imports").build()).describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Close").build()).click();
         try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
         
         //Create a new Software Policy - select the Software Policy target from the tree and then Actions - New menu
         afterLoginWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Library").build()).click();
         afterLoginWindow.describe(TreeView.class, new TreeViewDescription.Builder()
			.attachedText("Library").build()).select("By Type;Software Policies;Red Hat;Red Hat Enterprise Linux Server 5");
         try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
         afterLoginWindow.describe(Menu.class, new MenuDescription.Builder()
			.label("Actions").build()).click();
         try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
         afterLoginWindow.describe(Menu.class, new MenuDescription.Builder()
			.label("Actions").build()).selectSubMenu("New...");
         try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
         Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
			.title("Software Policy: New Software Policy*").build()).describe(Editor.class, new EditorDescription.Builder()
			.attachedText("Name:").build()).setText("test policy");
         try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
         testPolicyWindow.describe(TreeView.class, new TreeViewDescription.Builder()
			.attachedText("Views").build()).select("Software Policy:;Policy Items");
         
         // press the add button to add the zip file
         testPolicyWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("add16").build()).click();
         testPolicyWindow.describe(TreeView.class, new TreeViewDescription.Builder()
			.selectedNodes(new String[] { "#0;Application Configuration" }).build())
			.select("#0;Package");
         
         //enter 'test' in teh search field and select the test policy 
         testPolicyWindow.describe(Editor.class, new com.hp.lft.sdk.java.EditorDescription.Builder()
			.tagName("JTextField").nativeClass("javax.swing.JTextField").build()).setText("test");  
         testPolicyWindow.describe(Table.class, new TableDescription.Builder()
			.objectName("com.opsware.ngui.library.ui.panels.LibraryFilterPanel").build()).selectRows(0);
         testPolicyWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Select").build()).click();
         testPolicyWindow.close();
         testPolicyWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("No").build()).click();
        
        //Select the managed server to which we want to attach the policy 
         afterLoginWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Devices").build()).click();
         afterLoginWindow.describe(TreeView.class, new TreeViewDescription.Builder()
			.attachedText("Devices").build()).select("Devices;Servers;All Managed Servers");
         afterLoginWindow.describe(Table.class, new TableDescription.Builder()
			.objectName("server-table").build()).selectRows(1); 
        
        //Attach the Policy 
         try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}  
         afterLoginWindow.describe(Menu.class, new MenuDescription.Builder()
			.label("Actions").build()).click();
         try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
         afterLoginWindow.describe(Menu.class, new MenuDescription.Builder()
			.label("Actions").build()).selectSubMenu("Attach;Software Policy...");
         try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
//         afterLoginWindow.describe(Table.class, new TableDescription.Builder()
//			.objectName("com.opsware.ngui.library.ui.panels.LibraryFilterPanel").build()).getRows();
		 System.out.println(afterLoginWindow.describe(Table.class, new TableDescription.Builder()
			.objectName("com.opsware.ngui.library.ui.panels.LibraryFilterPanel").build()).getTextLocations("test"));
//		 afterLoginWindow.describe(Table.class, new TableDescription.Builder()
//			.objectName("com.opsware.ngui.library.ui.panels.LibraryFilterPanel").build()).selectRows(5);
		 
		 
		 Table table =Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
			.title("HPE Server Automation - 192.168.178.30").build()).describe(Dialog.class, new DialogDescription.Builder()
			.title("Attach Software Policy").build()).describe(Table.class, new TableDescription());
		
				 
		 for (TableRow row:table.getRows()){
			 for (TableCell cell:row.getCells() ){
				 System.out.println(cell.getValue().toString());
				 if (cell.getValue().toString().equals("Test Policy")) {
					 cell.click();
					 //System.out.println("Found");
				}
				 //else  System.out.println("Not Found");
			 }
		 }
		
		// afterLoginWindow.describe(Table.class, table ).selectRows(table.getRows(5))

//         Table policy = afterLoginWindow.describe(Table.class, new TableDescription.Builder()
//			.objectName("com.opsware.ngui.library.ui.panels.LibraryFilterPanel").build());
//          Object test = policy.selectCell(5, 1);
//         
//         Verify.areEqual("Test Policy",policy.selectCell(5, 1));
         
		 
		 
         afterLoginWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Attach").build()).click();
         Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
			.title("Remediate").build()).describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Start Job").build()).click();
         try {Thread.sleep(15000);} catch (InterruptedException e) {e.printStackTrace();}
       //  Verify.areEqual("Succeedeed", )
//         UiObjectDescription test = new UiObjectDescription.Builder().attachedText("Job Status")
//        		 .nativeClass("com.opsware.ngui.apppolicy.task.RemediatePoliciesTask$2").build();
        
    
         
//         System.out.println(Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
//			.title(new RegExpProperty("Remediate.*")).build()).describe(UiObject.class, new UiObjectDescription.Builder()
//			.attachedText("Job Status").nativeClass("com.opsware.ngui.apppolicy.task.RemediatePoliciesTask$2").build()).getVisibleText());
         
         UiObject tabel = Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
			.title(new RegExpProperty("Remediate.*")).build()).describe(UiObject.class, new UiObjectDescription.Builder()
			.nativeClass("com.opsware.ngui.apppolicy.task.RemediatePoliciesTask$2").build());
         

         //String bitmapFolder = ("@C:\\Users\\mapt\\Desktop\\Images\\Reference1.bmp");
        		 try {
					RenderedImage expectedImage = ImageIO.read(new File("C:\\Users\\mapt\\Desktop\\Images\\Reference1.PNG"));
					if (tabel.verifyImageMatch(expectedImage))
						System.out.println("BINGO!!!!");
							;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        		 
        		
//		 for (TableRow row:tabel.getRows()){
//			 for (TableCell cell:row.getCells() ){
        		
//					System.out.println(tabel.findChildren(UiObject.class, tabel.getDescription()).toString());
//					System.out.println(tabel.getAttachedText().toString());
//					System.out.println(tabel.getDisplayName().toString());
					System.out.println(tabel.getVisibleText().toString());
					String rezultat = tabel.getVisibleText().toString();
					if (rezultat.contains("Succeeded")) System.out.println ("PROBLEM SOLVED!!!!");
					try{
						assertTrue(rezultat.contains("Succeeded"));
					}
					catch(AssertionError e){
			             // Adds a step to the results report on failure. 
						System.out.println("VREAU SA VAD CUM FUNCTIONEAZA!!!!");
			            throw e;
			        }
//				 if (cell.getValue().toString().equals("Test Policy")) {
//					//cell.click();
//					 System.out.println("Found");
//				}
//				 else  System.out.println("Not Found");
//			 }
//		 }
         
         
         Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
			.title(new RegExpProperty("Remediate.*")).build()).describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
			.label("Close").build()).click();
	}

	@After
	public void tearDown() throws Exception {
		Window afterLoginWindow =  Desktop.describe(Window.class, new com.hp.lft.sdk.java.WindowDescription.Builder()
		.title("HPE Server Automation - 192.168.178.30").build());
		
		afterLoginWindow.close();
		afterLoginWindow.describe(Button.class, new com.hp.lft.sdk.java.ButtonDescription.Builder()
		.label("Yes").build()).click();	
	}
}
 